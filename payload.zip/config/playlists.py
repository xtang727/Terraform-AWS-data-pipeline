def spotify_playlists():
    playlists = {'Chillin on a Dirt Road': 'https://open.spotify.com/playlist/37i9dQZF1DWTkxQvqMy4WW?si=f03bbae4c2d842b1'}
    return playlists